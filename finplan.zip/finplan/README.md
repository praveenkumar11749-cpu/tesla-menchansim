# FinPlan - Personal Financial Planner (Java 21 · Tomcat 9 · Maven)

A servlet-based REST API plus single-page UI covering:

| Area | Endpoint | What it does |
|---|---|---|
| Investments | `POST /api/sip` | SIP + lumpsum + annual step-up, inflation-adjusted value, growth chart |
| Goals | `POST /api/goal` | Education/house/wedding goals with goal-specific inflation, SIP or one-time amount needed |
| Tax (India) | `POST /api/tax` | New vs old regime (FY 2025-26 slabs, 87A rebate, cess), 80C/80D/NPS/HRA tips |
| Savings | `POST /api/savings` | 50/30/20 budget, emergency fund target, savings rate, FD pre/post-tax maturity |
| Insurance | `POST /api/insurance` | Term cover (income replacement), health base + super top-up, critical illness |
| Retirement | `POST /api/retirement` | Inflation-adjusted corpus, SIP gap, readiness %, FIRE number |
| Loans | `POST /api/loan` | EMI, prepayment impact (interest and months saved), balance chart |
| Allocation | `POST /api/allocation` | Equity/debt/gold mix by age and risk, expected return, drawdown |
| Net worth | `POST /api/networth` | Assets, liabilities, leverage, liquidity |
| Health | `GET /api/health` | Liveness probe for load balancers |

## Run locally
    mvn clean package          # runs tests, builds target/ROOT.war
    docker build -t finplan . && docker run -p 8080:8080 finplan
    # or drop target/ROOT.war into any Tomcat 9.0.83+ running on JDK 21
Open http://localhost:8080

## Cloud deployment
- **AWS Elastic Beanstalk**: platform "Tomcat 9 with Corretto 21", upload `target/ROOT.war`.
- **Azure App Service**: Java 21 + Tomcat 9.0 stack, `az webapp deploy --type war --src-path target/ROOT.war`.
- **GCP Cloud Run / AWS ECS / Azure Container Apps / Render**: deploy the `Dockerfile` image (port 8080, health path `/api/health`).
- **Kubernetes**: use the image, `readinessProbe` on `/api/health`.

## Notes
- Tomcat 9 uses `javax.servlet.*` (do not migrate to `jakarta.*` unless you move to Tomcat 10+).
- Tax slabs live in `TaxService`; update them every Budget. Surcharge is not modelled.
- The planners are stateless: no database, so it scales horizontally with no session affinity.
- Ideas to extend: user accounts + saved plans (PostgreSQL/JPA), Monte-Carlo simulation, mutual-fund NAV feeds, PDF report export, NPS/PPF/EPF calculators, SWP and capital-gains tax planners, real-estate rent-vs-buy, crypto/ESOP tax modules.
