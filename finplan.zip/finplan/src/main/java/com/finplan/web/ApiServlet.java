package com.finplan.web;

import com.finplan.service.PlanService;
import com.finplan.service.TaxService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.function.UnaryOperator;

/** Single JSON gateway: POST /api/{sip|goal|tax|savings|insurance|retirement|loan|allocation|networth}, GET /api/health. */
@WebServlet(urlPatterns = "/api/*")
public class ApiServlet extends HttpServlet {
    private static final Gson GSON = new Gson();
    private static final java.lang.reflect.Type MAP_TYPE = new TypeToken<Map<String, Object>>() { }.getType();

    private static final Map<String, UnaryOperator<Map<String, Object>>> ROUTES = Map.of(
            "sip", PlanService::sip,
            "goal", PlanService::goal,
            "tax", TaxService::compare,
            "savings", PlanService::savings,
            "insurance", PlanService::insurance,
            "retirement", PlanService::retirement,
            "loan", PlanService::loan,
            "allocation", PlanService::allocation,
            "networth", PlanService::networth);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        if ("/health".equals(req.getPathInfo())) {
            write(resp, 200, Map.of("status", "UP", "java", Runtime.version().toString(), "endpoints", ROUTES.keySet()));
        } else {
            write(resp, 404, Map.of("error", "Use POST /api/{" + String.join("|", ROUTES.keySet()) + "}"));
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String path = req.getPathInfo() == null ? "" : req.getPathInfo().replaceFirst("^/", "");
        var handler = ROUTES.get(path);
        if (handler == null) { write(resp, 404, Map.of("error", "Unknown planner: " + path)); return; }
        try {
            String body = new String(req.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
            Map<String, Object> in = body.isBlank() ? Map.of() : GSON.fromJson(body, MAP_TYPE);
            write(resp, 200, handler.apply(in));
        } catch (IllegalArgumentException | com.google.gson.JsonParseException e) {
            write(resp, 400, Map.of("error", String.valueOf(e.getMessage())));
        } catch (RuntimeException e) {
            log("Planner failure: " + path, e);
            write(resp, 500, Map.of("error", "Internal error"));
        }
    }

    private void write(HttpServletResponse resp, int status, Object body) throws IOException {
        resp.setStatus(status);
        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");
        resp.setHeader("Cache-Control", "no-store");
        resp.getWriter().write(GSON.toJson(body));
    }
}
