package com.finplan.service;

import static com.finplan.service.FinanceMath.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Stateless planners: investments, goals, savings, insurance, retirement, loans, allocation, net worth. */
public final class PlanService {
    private PlanService() {}

    private static Map<String, Object> point(int year, double a, double b, String ka, String kb) {
        return res("year", (double) year, ka, a, kb, b);
    }

    // ---------------------------------------------------------------- Investments (SIP + lumpsum + step-up)
    public static Map<String, Object> sip(Map<String, Object> m) {
        double monthly = d(m, "monthly", 0), years = d(m, "years", 10), ret = d(m, "returnPct", 12);
        double step = d(m, "stepUpPct", 0), inf = d(m, "inflationPct", 6), lump = d(m, "lumpsum", 0);
        require(years >= 1 && years <= 60, "Years must be between 1 and 60");
        require(monthly >= 0 && lump >= 0, "Amounts must be non-negative");

        double r = monthlyRate(ret), bal = lump, invested = lump, s = monthly;
        List<Map<String, Object>> series = new ArrayList<>();
        int n = (int) (years * 12);
        for (int i = 1; i <= n; i++) {
            if (i > 1 && (i - 1) % 12 == 0) s *= 1 + step / 100;
            bal = (bal + s) * (1 + r);
            invested += s;
            if (i % 12 == 0) series.add(point(i / 12, invested, bal, "invested", "value"));
        }
        return res("totalInvested", invested, "futureValue", bal, "gains", bal - invested,
                "valueInTodaysMoney", bal / Math.pow(1 + inf / 100, years),
                "wealthMultiple", invested > 0 ? bal / invested : 0.0, "series", series);
    }

    // ---------------------------------------------------------------- Goal planner (education, house, wedding...)
    public static Map<String, Object> goal(Map<String, Object> m) {
        double target = d(m, "targetToday", 0), years = d(m, "years", 10), ret = d(m, "returnPct", 11);
        double inf = d(m, "inflationPct", 8), current = d(m, "currentSavings", 0);
        require(years >= 1 && years <= 50, "Years must be between 1 and 50");
        require(target > 0, "Target amount must be positive");

        double futureTarget = target * Math.pow(1 + inf / 100, years);
        double fvCurrent = current * Math.pow(1 + ret / 100, years);
        double need = Math.max(0, futureTarget - fvCurrent);
        double factor = annuityDueFactor(monthlyRate(ret), (int) (years * 12));
        return res("goalCostAtMaturity", futureTarget, "growthOfCurrentSavings", fvCurrent,
                "gapToFund", need, "monthlySipRequired", need / factor,
                "orOneTimeInvestmentToday", need / Math.pow(1 + ret / 100, years));
    }

    // ---------------------------------------------------------------- Savings: emergency fund, budget, FD
    public static Map<String, Object> savings(Map<String, Object> m) {
        double income = d(m, "monthlyIncome", 0), exp = d(m, "monthlyExpenses", 0), emi = d(m, "monthlyEmi", 0);
        double dependents = d(m, "dependents", 0), selfEmp = d(m, "selfEmployed", 0), have = d(m, "currentEmergencyFund", 0);
        double fd = d(m, "fdAmount", 0), fdRate = d(m, "fdRatePct", 7), fdYears = d(m, "fdYears", 3), slab = d(m, "taxSlabPct", 20);
        require(income > 0, "Monthly income must be positive");

        double months = 6 + (selfEmp > 0 ? 3 : 0) + (dependents >= 3 ? 2 : 0);
        double target = (exp + emi) * months;
        double surplus = income - exp - emi;
        double rate = surplus / income * 100;
        List<String> tips = new ArrayList<>();
        tips.add(rate >= 20 ? "Great savings rate - route the surplus to SIPs and goals."
                : "Savings rate is below the 20% benchmark; review discretionary expenses.");
        if (emi / income > 0.4) tips.add("EMIs exceed 40% of income - prioritise prepaying high-interest debt.");
        tips.add("Keep the emergency fund in liquid/overnight funds or a sweep-in FD, not in equities.");

        double fdPre = fd * Math.pow(1 + fdRate / 400, 4 * fdYears);
        double fdPost = fd * Math.pow(1 + (fdRate / 100) * (1 - slab / 100) / 4, 4 * fdYears);
        return res("budget503020", res("needs50", income * .5, "wants30", income * .3, "savings20", income * .2),
                "actualSurplus", surplus, "savingsRatePct", rate,
                "emergencyFundMonths", months, "emergencyFundTarget", target,
                "emergencyFundGap", Math.max(0, target - have),
                "monthsToBuildFundAtCurrentSurplus", surplus > 0 ? Math.ceil(Math.max(0, target - have) / surplus) : 0.0,
                "fdMaturityPreTax", fdPre, "fdMaturityPostTaxApprox", fdPost, "tips", tips);
    }

    // ---------------------------------------------------------------- Insurance: term + health + critical illness
    public static Map<String, Object> insurance(Map<String, Object> m) {
        double age = d(m, "age", 30), retire = d(m, "retireAge", 60), income = d(m, "annualIncome", 0);
        double exp = d(m, "monthlyExpenses", 0), loans = d(m, "outstandingLoans", 0), goals = d(m, "futureGoals", 0);
        double existing = d(m, "existingTermCover", 0), assets = d(m, "liquidAssets", 0);
        double ret = d(m, "returnPct", 8), inf = d(m, "inflationPct", 6);
        int tier = (int) d(m, "cityTier", 1), members = (int) d(m, "familyMembers", 3);
        require(retire > age, "Retirement age must be greater than current age");

        double real = (1 + ret / 100) / (1 + inf / 100) - 1;
        double replace = pvAnnuity(exp * 12, real, retire - age);
        double termGap = Math.max(0, replace + loans + goals - assets - existing);
        double term = Math.ceil(termGap / 500_000) * 500_000;

        double base = tier == 1 ? 1_000_000 : tier == 2 ? 750_000 : 500_000;
        double total = tier == 1 ? 5_000_000 : tier == 2 ? 3_000_000 : 2_000_000;
        if (members > 4) { base += 500_000; total += 1_000_000; }
        double ci = Math.min(Math.max(income * 3, 500_000), 5_000_000);

        List<String> tips = List.of(
                "Buy a pure term plan (not endowment/ULIP) with a claim-settlement ratio above 95%.",
                "Choose a base health policy plus a cheap super top-up to reach the total cover.",
                "Insure early - premiums rise sharply with age and pre-existing conditions.",
                "Add personal accident cover; check employer cover is not your only health cover.");
        return res("termCoverRecommended", term, "incomeReplacementNeed", replace,
                "healthBaseCover", base, "superTopUp", total - base, "healthTotalCover", total,
                "criticalIllnessCover", ci, "tips", tips);
    }

    // ---------------------------------------------------------------- Retirement / FIRE
    public static Map<String, Object> retirement(Map<String, Object> m) {
        double age = d(m, "age", 30), retire = d(m, "retireAge", 60), life = d(m, "lifeExpectancy", 85);
        double exp = d(m, "monthlyExpenses", 0), inf = d(m, "inflationPct", 6);
        double pre = d(m, "preReturnPct", 12), post = d(m, "postReturnPct", 8);
        double current = d(m, "currentSavings", 0), sip = d(m, "currentMonthlySip", 0);
        require(retire > age && life > retire, "Need current age < retirement age < life expectancy");

        double yrsTo = retire - age, yrsIn = life - retire;
        double expAtRet = exp * 12 * Math.pow(1 + inf / 100, yrsTo);
        double real = (1 + post / 100) / (1 + inf / 100) - 1;
        double corpus = pvAnnuity(expAtRet, real, yrsIn) * (1 + real);   // annuity-due
        double fvSavings = current * Math.pow(1 + pre / 100, yrsTo);
        double factor = annuityDueFactor(monthlyRate(pre), (int) (yrsTo * 12));
        double fvSip = sip * factor;
        double gap = Math.max(0, corpus - fvSavings - fvSip);
        return res("monthlyExpenseAtRetirement", expAtRet / 12, "corpusRequired", corpus,
                "projectedFromSavings", fvSavings, "projectedFromCurrentSip", fvSip,
                "shortfall", gap, "additionalMonthlySipNeeded", gap / factor,
                "readinessPct", corpus > 0 ? Math.min(100, (fvSavings + fvSip) / corpus * 100) : 0.0,
                "fireNumber25x", exp * 12 * 25);
    }

    // ---------------------------------------------------------------- Loans with prepayment
    public static Map<String, Object> loan(Map<String, Object> m) {
        double p = d(m, "principal", 0), rate = d(m, "ratePct", 9), years = d(m, "years", 20), extra = d(m, "extraMonthly", 0);
        require(p > 0 && years >= 1, "Principal and tenure must be positive");
        int n = (int) (years * 12);
        double emi = emi(p, rate, n), r = rate / 1200, bal = p, interest = 0;
        List<Map<String, Object>> series = new ArrayList<>();
        int month = 0;
        while (bal > 0.005 && month < 1200) {
            month++;
            double i = bal * r, pay = Math.min(emi + extra, bal + i);
            interest += i;
            bal = bal + i - pay;
            if (month % 12 == 0 || bal <= 0.005) series.add(point((int) Math.ceil(month / 12.0), Math.max(0, bal), 0, "balance", "x"));
        }
        series.forEach(row -> row.remove("x"));
        double baseInterest = emi * n - p;
        return res("emi", emi, "totalInterestNoPrepay", baseInterest, "totalInterestWithPrepay", interest,
                "interestSaved", baseInterest - interest, "monthsSaved", (double) (n - month),
                "newTenureMonths", (double) month, "series", series);
    }

    // ---------------------------------------------------------------- Asset allocation
    public static Map<String, Object> allocation(Map<String, Object> m) {
        double age = d(m, "age", 30), risk = d(m, "risk", 2);   // 1 conservative, 2 moderate, 3 aggressive
        require(age >= 18 && age <= 90 && risk >= 1 && risk <= 3, "Age 18-90 and risk 1-3 required");
        double equity = Math.max(20, Math.min(75, 110 - age + (risk - 2) * 10));
        double gold = 10, debt = 100 - equity - gold;
        double expected = (equity * 12 + debt * 7 + gold * 8) / 100;
        double drawdown = (equity * -40 + debt * -3 + gold * -15) / 100;
        return res("equityPct", equity, "debtPct", debt, "goldPct", gold,
                "equitySplit", res("indexFundsPct", equity * .6, "flexiOrMidCapPct", equity * .3, "internationalPct", equity * .1),
                "debtSplit", res("shortDurationOrPpfEpfPct", debt * .7, "gSecOrCorporateBondPct", debt * .3),
                "expectedReturnPct", expected, "worstCaseDrawdownPct", drawdown,
                "tips", List.of("Rebalance once a year or when a bucket drifts more than 5%.",
                        "Use low-cost index funds for the core; keep gold via SGB/ETF.",
                        "Assumed long-run returns: equity 12%, debt 7%, gold 8% - not guarantees."));
    }

    // ---------------------------------------------------------------- Net worth
    public static Map<String, Object> networth(Map<String, Object> m) {
        double cash = d(m, "cash", 0), equity = d(m, "equityAndMf", 0), retirementAcc = d(m, "epfPpfNps", 0);
        double property = d(m, "realEstate", 0), gold = d(m, "gold", 0), otherA = d(m, "otherAssets", 0);
        double home = d(m, "homeLoan", 0), car = d(m, "carLoan", 0), card = d(m, "creditCard", 0), otherL = d(m, "otherLoans", 0);
        double assets = cash + equity + retirementAcc + property + gold + otherA;
        double liab = home + car + card + otherL;
        require(assets + liab > 0, "Enter at least one asset or liability");
        return res("totalAssets", assets, "totalLiabilities", liab, "netWorth", assets - liab,
                "debtToAssetPct", assets > 0 ? liab / assets * 100 : 0.0,
                "liquidAssetsPct", assets > 0 ? (cash + equity) / assets * 100 : 0.0,
                "healthCheck", liab / Math.max(assets, 1) < 0.4 ? "Healthy leverage" : "High leverage - focus on debt reduction");
    }
}
