package com.finplan.service;

import java.util.LinkedHashMap;
import java.util.Map;

/** Core time-value-of-money helpers and request/response utilities. */
public final class FinanceMath {
    private FinanceMath() {}

    public static double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Reads a numeric field from the request map (accepts numbers or numeric strings). */
    public static double d(Map<String, Object> m, String key, double def) {
        Object o = m.get(key);
        if (o instanceof Number n) return n.doubleValue();
        if (o instanceof String s && !s.isBlank()) {
            try { return Double.parseDouble(s.trim()); } catch (NumberFormatException ignored) { }
        }
        return def;
    }

    /** Effective monthly rate from an annual percentage (e.g. 12 -> ~0.949%). */
    public static double monthlyRate(double annualPct) {
        return Math.pow(1 + annualPct / 100.0, 1.0 / 12) - 1;
    }

    /** Future-value factor of start-of-period payments of 1 for n periods. */
    public static double annuityDueFactor(double r, int n) {
        return Math.abs(r) < 1e-12 ? n : (Math.pow(1 + r, n) - 1) / r * (1 + r);
    }

    /** Present value of an annual amount for given years at a (real) rate fraction. */
    public static double pvAnnuity(double annual, double rate, double years) {
        return Math.abs(rate) < 1e-12 ? annual * years : annual * (1 - Math.pow(1 + rate, -years)) / rate;
    }

    public static double emi(double principal, double annualPct, int months) {
        if (months <= 0) throw new IllegalArgumentException("Tenure must be positive");
        double r = annualPct / 1200.0;
        if (r == 0) return principal / months;
        double p = Math.pow(1 + r, months);
        return principal * r * p / (p - 1);
    }

    public static void require(boolean ok, String msg) {
        if (!ok) throw new IllegalArgumentException(msg);
    }

    /** Builds an ordered response map from alternating key/value pairs; doubles are rounded to 2 dp. */
    public static Map<String, Object> res(Object... kv) {
        Map<String, Object> out = new LinkedHashMap<>();
        for (int i = 0; i < kv.length; i += 2) {
            Object v = kv[i + 1];
            if (v instanceof Double dv) v = Double.isFinite(dv) ? round2(dv) : 0.0;
            out.put((String) kv[i], v);
        }
        return out;
    }
}
