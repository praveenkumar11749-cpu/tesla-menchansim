package com.finplan.service;

import static com.finplan.service.FinanceMath.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Indian income-tax estimator (salaried, resident, below 60 years).
 * Slabs follow the FY 2025-26 / AY 2026-27 rules. Surcharge (income above 50L) is NOT modelled.
 * Always verify against the latest Finance Act / incometax.gov.in before filing.
 */
public final class TaxService {
    private TaxService() {}

    private static final double MAX = Double.MAX_VALUE;
    // {upper limit, rate}
    static final double[][] NEW_SLABS = {
            {400_000, 0}, {800_000, .05}, {1_200_000, .10}, {1_600_000, .15},
            {2_000_000, .20}, {2_400_000, .25}, {MAX, .30}};
    static final double[][] OLD_SLABS = {
            {250_000, 0}, {500_000, .05}, {1_000_000, .20}, {MAX, .30}};

    static double slabTax(double taxable, double[][] slabs) {
        double tax = 0, prev = 0;
        for (double[] s : slabs) {
            if (taxable > prev) tax += (Math.min(taxable, s[0]) - prev) * s[1];
            prev = s[0];
        }
        return tax;
    }

    public static double newRegimeTax(double gross, double employerNps) {
        double taxable = Math.max(0, gross - 75_000 - employerNps);
        double tax = slabTax(taxable, NEW_SLABS);
        if (taxable <= 1_200_000) tax = 0;                       // section 87A rebate
        else tax = Math.min(tax, taxable - 1_200_000);           // marginal relief
        return tax * 1.04;                                       // 4% cess
    }

    public static Map<String, Object> compare(Map<String, Object> m) {
        double gross = d(m, "income", 0), empNps = d(m, "employerNps", 0);
        double c80 = d(m, "sec80C", 0), d80 = d(m, "sec80D", 0), nps1b = d(m, "sec80CCD1B", 0);
        double hra = d(m, "hraExemption", 0), hli = d(m, "homeLoanInterest", 0), other = d(m, "otherDeductions", 0);
        require(gross >= 0, "Income must be non-negative");

        double newTaxable = Math.max(0, gross - 75_000 - empNps);
        double newTax = newRegimeTax(gross, empNps);

        double deductions = 50_000 + Math.min(c80, 150_000) + Math.min(d80, 100_000) + Math.min(nps1b, 50_000)
                + empNps + hra + Math.min(hli, 200_000) + other;
        double oldTaxable = Math.max(0, gross - deductions);
        double oldTax = slabTax(oldTaxable, OLD_SLABS);
        if (oldTaxable <= 500_000) oldTax = 0;                   // section 87A (old regime)
        oldTax *= 1.04;

        boolean newBetter = newTax <= oldTax;
        List<String> tips = new ArrayList<>();
        if (c80 < 150_000)
            tips.add("Section 80C headroom of ₹" + Math.round(150_000 - c80)
                    + " (EPF, PPF, ELSS, term premium) - useful only in the old regime.");
        if (nps1b < 50_000)
            tips.add("Extra NPS (80CCD(1B)) up to ₹" + Math.round(50_000 - nps1b) + " is deductible in the old regime.");
        if (d80 == 0)
            tips.add("Health-insurance premiums qualify under 80D (old regime) and give you real protection.");
        tips.add(newBetter
                ? "New regime is cheaper for you at the deductions entered."
                : "Old regime saves you money because your deductions are substantial - keep them documented.");
        tips.add("Employer NPS contribution (80CCD(2)) is deductible in BOTH regimes.");

        return res(
                "newRegime", res("taxableIncome", newTaxable, "totalTax", newTax,
                        "effectiveRatePct", gross > 0 ? newTax / gross * 100 : 0.0),
                "oldRegime", res("totalDeductions", deductions, "taxableIncome", oldTaxable, "totalTax", oldTax,
                        "effectiveRatePct", gross > 0 ? oldTax / gross * 100 : 0.0),
                "betterRegime", newBetter ? "NEW" : "OLD",
                "taxSaving", Math.abs(newTax - oldTax),
                "monthlyTakeHomeAfterTaxBest", (gross - Math.min(newTax, oldTax)) / 12,
                "tips", tips,
                "note", "Excludes surcharge (income > ₹50L). Estimates only - verify with a CA.");
    }
}
