package com.finplan.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Map;
import org.junit.jupiter.api.Test;

class PlanServiceTest {
    @Test void emiMatchesKnownValue() {
        assertEquals(44_986.0, FinanceMath.emi(5_000_000, 9, 240), 5.0);
    }
    @Test void newRegimeNoTaxUpTo12LakhTaxable() {
        assertEquals(0, TaxService.newRegimeTax(1_275_000, 0), 0.01);   // 12.75L - 75k std ded = 12L
    }
    @Test void newRegimeTaxOn20Lakh() {
        // taxable 19.25L: 0+20k+40k+60k+(19.25-16)*20% = 770k? -> 0+20,000+40,000+60,000+65,000=185,000 *1.04
        assertEquals(192_400, TaxService.newRegimeTax(2_000_000, 0), 1.0);
    }
    @Test void sipGrowsAboveInvested() {
        var r = PlanService.sip(Map.of("monthly", 10000.0, "years", 10.0, "returnPct", 12.0));
        assertTrue((double) r.get("futureValue") > (double) r.get("totalInvested"));
    }
    @Test void retirementRejectsBadAges() {
        assertThrows(IllegalArgumentException.class,
                () -> PlanService.retirement(Map.of("age", 60.0, "retireAge", 50.0)));
    }
}
